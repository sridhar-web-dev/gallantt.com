<?php
require_once '../../../config/config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: " . ABS_URL . "dir/admin/login.php");
    exit();
}
$limit = 10; // Records per page
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

try {
    $db = Database::getDB();

    // Get total count
    $countStmt = $db->query("SELECT COUNT(*) FROM web_jobapplication

");
    $totalRecords = $countStmt->fetchColumn();
    $totalPages = ceil($totalRecords / $limit);

    // Fetch paginated records
    $stmt = $db->prepare("SELECT id, job_id, job_title, name, email, resume_file, applied_at 
                          FROM web_jobapplication

 
                          ORDER BY applied_at DESC 
                          LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<div class='text-danger'>Error: " . $e->getMessage() . "</div>";
    exit;
}
?>

<?php if (count($applications) > 0): ?>
   <div class="table-responsive">
   <table class="table table-bordered table-striped">
        <thead >
            <tr>
                <th>#</th>
                <th>Job Title</th>
                <th>Candidate Name</th>
                <th>Email</th>
                <th>Resume</th>
                <th>Applied At</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($applications as $index => $app): ?>
                <tr>
                    <td><?= $offset + $index + 1 ?></td>
                    <td><?= htmlspecialchars($app['job_title']) ?></td>
                    <td><?= htmlspecialchars($app['name']) ?></td>
                    <td><?= htmlspecialchars($app['email']) ?></td>
                    <td>
                        <?php if (!empty($app['resume_file'])): ?>
                            <a href="../../../uploads/resumes/<?= htmlspecialchars($app['resume_file']) ?>" target="_blank">View</a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                    <td><?= strtoupper(date("d M Y", strtotime($app['applied_at']))) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
   </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <!-- Pagination -->
    <nav>
        <ul class="pagination justify-content-center">
            <?php if ($page > 1): ?>
                <li class="page-item">
                    <a class="page-link application-page-link" href="#" data-page="<?= $page - 1 ?>">Prev</a>
                </li>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                    <a class="page-link application-page-link" href="#" data-page="<?= $i ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($page < $totalPages): ?>
                <li class="page-item">
                    <a class="page-link application-page-link" href="#" data-page="<?= $page + 1 ?>">Next</a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>


<?php else: ?>
    <p class="text-muted">No job applications found.</p>
<?php endif; ?>
