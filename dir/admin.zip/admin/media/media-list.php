<?php
require_once '../../../config/config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: " . ABS_URL . "dir/admin/login.php");
    exit();
}
$media = new Media();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Media Gallery</title>
    <link rel="stylesheet" href="../components/navbar/header.css">
    <link rel="stylesheet" href="<?= ABS_URL ?>assets/bootstrap/dist/css/bootstrap.min.css">    
    <link rel="icon" href="<?php echo ABS_URL ?>assets/home/gallantt-group-of-industries.svg" sizes="32x32">
    <link rel="icon" href="<?php echo ABS_URL ?>assets/home/gallantt-group-of-industries.svg" sizes="192x192">
    <link rel="apple-touch-icon" href="<?php echo ABS_URL ?>assets/home/gallantt-group-of-industries.svg">
</head>
<body>
<?php require_once '../components/navbar/header.php'; ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg">
                <div class="card-header bg-light text-dark d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Media Gallery</h4>
                    <a href="media-form.php" class="btn btn-secondary">Add New Media</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive" id="mediaTableContainer">
                        <!-- Media gallery table will be loaded here via AJAX -->
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
        <div class="alert alert-primary mb-0">
                    <div>Changes you made are now live on the Media page.</div>
                    <a href="<?php echo ABS_URL; ?>media" target="_blank" class="btn btn-sm btn-primary mt-2 w-100"><i class="fa fa-eye"></i> View on Website</a>
               </div>
        </div>
    </div>
</div>
<script src="<?php echo ABS_URL ?>dir/admin/jquery.3.6.1.js"></script>
<script src="<?= ABS_URL ?>assets/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function () {
    function loadMedia() {
        $.ajax({
            url: "fetch-media.php",
            type: "GET",
            success: function (response) {
                $("#mediaTableContainer").html(response);
            }
        });
    }
    loadMedia(); // Initial load
    $(document).on("click", ".toggleStatus", function () {
        let mediaId = $(this).data("id");
        let newStatus = $(this).data("status") === "live" ? "disabled" : "live";
        $.ajax({
            url: "media-status-toggle.php",
            type: "POST",
            data: { media_id: mediaId, status: newStatus },
            success: function (response) {
                alert(response);
                loadMedia();
            }
        });
    });
    $(document).on("click", ".deleteMedia", function () {
        let mediaId = $(this).data("id");
        if (confirm("Are you sure you want to delete this media?")) {
            $.ajax({
                url: "media-delete.php",
                type: "POST",
                data: { media_id: mediaId },
                success: function (response) {
                    alert(response);
                    loadMedia();
                }
            });
        }
    });
});
</script>
</body>
</html>
