<?php
require_once '../../../config/config.php';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["media_id"])) {
    $media = new Media();
    if ($media->deleteMedia($_POST["media_id"])) {
        clearVarnishCache();
        echo "Media deleted successfully.";
    } else {
        echo "Failed to delete media.";
    }
} else {
    echo "Invalid request.";
}
?>
