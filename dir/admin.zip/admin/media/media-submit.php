<?php
require_once '../../../config/config.php';

$media = new Media();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $media_id       = $_POST['media_id'] ?? null;
    $media_name     = $_POST['media_name'] ?? '';
    $category       = $_POST['category'] ?? '';
    $section        = $_POST['section'] ?? '';
    $description    = $_POST['description'] ?? '';
    $date_of_post   = $_POST['date_of_post'] ?? '';
    $media_type     = $_POST['media_type'] ?? ''; // ✅ Directly get from form
    $media_image    = '';
    $media_file     = '';
    $media_file_type = '';

    $uploadDir = '../../../uploads/media/uploads/';

    // Handle image/video thumbnail upload
    if (!empty($_FILES['media_image']['name'])) {
        $fileExt = pathinfo($_FILES['media_image']['name'], PATHINFO_EXTENSION);
        $fileName = "MEDIA_IMG_" . date('Ymdhis') . "_" . rand(100, 999) . "." . $fileExt;
        $targetFile = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['media_image']['tmp_name'], $targetFile)) {
            $media_image = $fileName;

            // ✅ If media_type not manually chosen, fallback to file MIME
            if (empty($media_type)) {
                $fileType = mime_content_type($targetFile);
                if (strpos($fileType, 'image') !== false) {
                    $media_type = 'image';
                } elseif (strpos($fileType, 'video') !== false) {
                    $media_type = 'video';
                } elseif (strpos($fileType, 'application') !== false) {
                    $media_type = 'document';
                } else {
                    $media_type = 'unknown';
                }
            }
        }
    }

    // Handle additional media file upload (video/document)
    if (!empty($_FILES['media_file']['name'])) {
        $fileExt2 = pathinfo($_FILES['media_file']['name'], PATHINFO_EXTENSION);
        $fileName2 = "MEDIA_FILE_" . date('Ymdhis') . "_" . rand(100, 999) . "." . $fileExt2;
        $targetFile2 = $uploadDir . $fileName2;

        if (move_uploaded_file($_FILES['media_file']['tmp_name'], $targetFile2)) {
            $media_file = $fileName2;

            // Detect file type for uploaded media file
            $fileType2 = mime_content_type($targetFile2);
            if (strpos($fileType2, 'video') !== false) {
                $media_file_type = 'video';
            } elseif (strpos($fileType2, 'application') !== false) {
                $media_file_type = 'document';
            } else {
                $media_file_type = 'unknown';
            }
        }
    }

    // ✅ Insert or update logic
    if ($media_id) {
        $existingMedia = $media->getMediaById($media_id);

        // Replace image if new uploaded
        if (!empty($media_image) && !empty($existingMedia['media_image'])) {
            $oldImage = $uploadDir . $existingMedia['media_image'];
            if (file_exists($oldImage)) unlink($oldImage);
        } else {
            $media_image = $existingMedia['media_image'];
        }

        // Replace file if new uploaded
        if (!empty($media_file) && !empty($existingMedia['media_file'])) {
            $oldFile = $uploadDir . $existingMedia['media_file'];
            if (file_exists($oldFile)) unlink($oldFile);
        } else {
            $media_file = $existingMedia['media_file'];
            $media_file_type = $existingMedia['media_file_type'];
        }

        // ✅ Keep existing media_type if not changed
        if (empty($media_type)) {
            $media_type = $existingMedia['media_type'];
        }

        $update = $media->updateMedia(
            $media_id, $media_name, $section, $category, $description, $date_of_post,
            $media_image, $media_type, $media_file, $media_file_type
        );
        if ($update) {
            clearVarnishCache();
            echo 'Media updated successfully!';
        } else {
            echo 'Update failed.';
        }
    } else {
        $insert = $media->addMedia(
            $media_name, $section, $category, $description, $date_of_post,
            $media_image, $media_type, $media_file, $media_file_type
        );
        if ($insert) {
            clearVarnishCache();
            echo 'Media added successfully!';
        } else {
            echo 'Insertion failed.';
        }
    }
}
?>