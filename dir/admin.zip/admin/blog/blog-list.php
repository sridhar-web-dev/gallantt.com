<?php
require_once '../../../config/config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: " . ABS_URL . "dir/admin/login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Listings</title>
    <link rel="stylesheet" href="../components/navbar/header.css">
    <link rel="stylesheet" href="<?= ABS_URL ?>assets/bootstrap/dist/css/bootstrap.min.css">
    <link rel="icon" href="<?php echo ABS_URL ?>assets/home/gallantt-group-of-industries.svg" sizes="32x32">
    <link rel="icon" href="<?php echo ABS_URL ?>assets/home/gallantt-group-of-industries.svg" sizes="192x192">
    <link rel="apple-touch-icon" href="<?php echo ABS_URL ?>assets/home/gallantt-group-of-industries.svg">
</head>
<body>
<?php require_once '../components/navbar/header.php'; ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-lg-8">
        <div class="card">
        <div class="card-header bg-light text-dark d-flex justify-content-between align-items-center">
            <h2>Blog Listings</h2>
            <a href="blog-form.php" class="btn btn-secondary ">Add New Blog</a>
        </div>
        <div class="card-body">
       <div class="table-responsive">
       <div id="blogTableContainer"></div> <!-- Only this will load the table dynamically -->
<!-- Hide pagination if total blogs are less than the limit -->
<?php if ($totalBlogs > $limit) : ?>
    <div class="pagination mt-3">
        <?php for ($i = 1; $i <= $totalPages; $i++) : ?>
            <button class="btn <?= $i == $page ? 'btn-primary' : 'btn-light' ?> page-link" data-page="<?= $i ?>"><?= $i ?></button>
        <?php endfor; ?>
    </div>
<?php endif; ?>
       </div>
        </div>
    </div>
        </div>
        <div class="col-lg-4">
        <div class="alert alert-primary mb-0">
                    <div>Changes you made are now live on the Blog page.</div>
                    <a href="<?php echo ABS_URL; ?>blogs/1/" target="_blank" class="btn btn-sm btn-primary mt-2 w-100"><i class="fa fa-eye"></i> View on Website</a>
               </div>
        </div>
    </div>
</div>
</body>
<script src="<?php echo ABS_URL ?>dir/admin/jquery.3.6.1.js"></script>
<script src="<?= ABS_URL ?>assets/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function() {
        $(document).on('click', '.deleteBlog', function() {
        if (confirm('Are you sure you want to delete this blog?')) {
            var blogId = $(this).data('id');
            $.ajax({
                url: 'delete-blog.php', // create this file
                type: 'POST',
                data: { blog_id: blogId },
                success: function(response) {
                    alert(response);
                    location.reload(); // reload after delete
                }
            });
        }
    });

    // Toggle blog status (Enable/Disable)
    $(document).on('click', '.toggleStatus', function() {
        var blogId = $(this).data('id');
        var currentStatus = $(this).data('status');
        var newStatus = currentStatus == 1 ? 0 : 1;
        $.ajax({
            url: 'toggle-blog-status.php', // create this file
            type: 'POST',
            data: { blog_id: blogId, status: newStatus },
            success: function(response) {
                alert(response);
                location.reload(); // reload after status change
            }
        });
    });

    function loadBlogs(page) {
        $.ajax({
            url: "fetch-blog.php",
            type: "POST",
            data: { page: page },
            success: function(response) {
                $("#blogTableContainer").html(response);
            }
        });
    }
    // Load first page on document ready
    loadBlogs(1);
    // Handle pagination click
    $(document).on("click", ".page-link", function() {
        let page = $(this).data("page");
        loadBlogs(page);
    });
});
</script>
</html>
