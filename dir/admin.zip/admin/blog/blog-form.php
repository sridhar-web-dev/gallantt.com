<?php
require_once '../../../config/config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: " . ABS_URL . "dir/admin/login.php");
    exit();
}
$blog = new Blog();
$blogData = null;
if (isset($_GET['blog_id'])) {
    $blogData = $blog->getBlogById($_GET['blog_id']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title><?= isset($blogData) ? 'Edit Blog' : 'Create Blog' ?></title>
    <link rel="stylesheet" href="../components/navbar/header.css">
    <link rel="stylesheet" href="<?= ABS_URL ?>assets/bootstrap/dist/css/bootstrap.min.css">
    <link rel="icon" href="<?php echo ABS_URL ?>assets/home/gallantt-group-of-industries.svg" sizes="32x32">
    <link rel="icon" href="<?php echo ABS_URL ?>assets/home/gallantt-group-of-industries.svg" sizes="192x192">
    <link rel="apple-touch-icon" href="<?php echo ABS_URL ?>assets/home/gallantt-group-of-industries.svg">
    <!-- CKEditor 5 CDN -->
    <script src="<?php echo ABS_URL ?>dir/admin/ckeditor.js"></script>
</head>
<body>
<?php require_once '../components/navbar/header.php'; ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-lg-8">
        <div class="card shadow-lg">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h2><?= isset($blogData) ? 'Edit Blog' : 'Create Blog' ?></h2>
            
            <a href="blog-list.php" class="btn btn-secondary ">Manage Blog</a>
        </div>
        <div class="card-body">
        <div id="message" class="mt-3"></div>
            <form id="blogForm" enctype="multipart/form-data">
                <input type="hidden" name="blog_id" value="<?= $blogData['blog_id'] ?? '' ?>">
                <div class="mb-3">
                    <label>Blog Title</label>
                    <input type="text" class="form-control" name="title" value="<?= $blogData['title'] ?? '' ?>" required>
                </div>
                <div class="mb-3">
    <label>Blog Image</label>
    <div id="imagePreview" class="mb-2">
        <?php if (isset($blogData)) : ?>
            <img src="uploads/<?= $blogData['image'] ?>" id="previewImg" width="100" class="border p-1">
        <?php else : ?>
            <img src="#" id="previewImg" width="100" class="border p-1" style="display: none;">
        <?php endif; ?>
    </div>
    <input type="file" class="form-control" name="image" id="imageInput" <?= isset($blogData) ? '' : 'required' ?>>
</div>
                <div class="mb-3">
                    <label>Blog Description</label>
                    <textarea id="editor" class="form-control" name="description" required style="position: absolute; left: -9999px;"><?= $blogData['description'] ?? '' ?>
</textarea>
                </div>
                <button type="submit" class="btn btn-primary w-100"><?= isset($blogData) ? 'Update' : 'Submit' ?></button>
            </form>
        </div>
    </div>
        </div>
        <div class="col-lg-4">
        <div class="alert alert-primary mb-0">
                    <div>Changes you made are now live on the Blog page.</div>
                    <a href="<?php echo ABS_URL; ?>blogs/1/" target="_blank" class="btn btn-sm btn-primary mt-2 w-100"><i class="fa fa-eye"></i> View on Website</a>
               </div>
        </div>
    </div>
   
</div>
<script src="<?php echo ABS_URL ?>dir/admin/jquery.3.6.1.js"></script>
<script src="<?= ABS_URL ?>assets/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script>
      $(document).ready(function() {
    let blogEditor;
    // Initialize CKEditor
    ClassicEditor
        .create(document.querySelector('#editor'))
        .then(editor => {
            blogEditor = editor;
            editor.ui.view.editable.element.style.minHeight = '300px'; // Set editor height
            // Remove required attribute from the hidden textarea to prevent validation issues
            $("textarea[name='description']").removeAttr('required');
        })
        .catch(error => {
            console.error("CKEditor initialization failed:", error);
        });
    // Image Preview on File Change
    $("#imageInput").change(function () {
        let file = this.files[0];
        if (file) {
            let reader = new FileReader();
            reader.onload = function (e) {
                $("#previewImg").attr("src", e.target.result).show();
            };
            reader.readAsDataURL(file);
        }
    });
    // Form Submission with CKEditor Content
    $("#blogForm").on("submit", function(e) {
        e.preventDefault();
        // Ensure CKEditor is initialized before accessing getData()
        if (blogEditor) {
            let editorContent = blogEditor.getData().trim(); // Trim to prevent spaces being counted
            $("textarea[name='description']").val(editorContent);
            // If CKEditor is empty, prevent form submission and show an error
            if (editorContent === "") {
                $("#message").html('<div class="alert alert-danger">Blog description is required.</div>');
                return;
            }
        } else {
            console.warn("CKEditor not initialized. Submitting empty content.");
            $("textarea[name='description']").val(""); // Fallback to empty text
        }
        var formData = new FormData(this);
        $.ajax({
            url: "blog-submit.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                $("#message").html(response).addClass('alert alert-success');
                setTimeout(() => window.location.href = 'blog-list.php', 2000);
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", status, error);
                $("#message").html('<div class="alert alert-danger">Submission failed. Please try again.</div>');
            }
        });
    });
});
</script>
</body>
</html>
