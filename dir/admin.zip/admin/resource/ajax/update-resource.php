<?php
require_once '../../../../config/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $resourceObj = new Resources();
    $pdo = Database::getDB(); // Use your static Database class

    $resourceId = $_POST['resource_id'];
    $categoryId = $_POST['category_id'];
    $newCategory = $_POST['new_category'];
    $resourceName = $_POST['resource_name'];
    $file = $_FILES['resource_file'];

    // If new category is entered
    if (!empty($newCategory)) {
        $categoryId = $resourceObj->addCategory($newCategory);
    }

    $updateData = [
        ':resource_id' => $resourceId,
        ':category_id' => $categoryId,
        ':resource_name' => $resourceName
    ];

    $sql = "UPDATE web_resources SET category_id = :category_id, resource_name = :resource_name";

    if ($file['error'] == 0) {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['pdf', 'doc', 'docx', 'mp4', 'mov', 'avi'];

        if (!in_array($ext, $allowed)) {
            echo 'Invalid file type.';
            exit;
        }

        $uploadDir = "../../uploads/resources/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $filename = "RES_" . date('Y_m_d_H_i_s') . "_" . rand(100, 999) . "." . $ext;
        $targetPath = $uploadDir . $filename;

        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            $updateData[':file_path'] = "uploads/resources/" . $filename;
            $sql .= ", file_path = :file_path";
        } else {
            echo 'File upload failed.';
            exit;
        }
    }

    $sql .= " WHERE id = :resource_id";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($updateData);
    clearVarnishCache();

    echo 'Resource updated successfully.';
}
