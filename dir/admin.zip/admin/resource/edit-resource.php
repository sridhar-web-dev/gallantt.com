<?php
require_once '../../../config/config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: " . ABS_URL . "dir/admin/login.php");
    exit();
}
$resourceObj = new Resources();
$categories = $resourceObj->getCategories();

if (isset($_GET['id'])) {
    $resourceId = $_GET['id'];
    $resource = $resourceObj->getResourceById($resourceId); // Assuming getResourceById method exists
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resource</title>
    <link rel="stylesheet" href="../components/navbar/header.css">
    <link rel="stylesheet" href="<?= ABS_URL ?>assets/bootstrap/dist/css/bootstrap.min.css">
    <script src="<?php echo ABS_URL ?>dir/admin/ckeditor.js"></script>
    <!-- Select2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

</head>
<body>
<?php require_once '../components/navbar/header.php'; ?>
<div class="container my-5">
   <div class="row justify-content-center">
    <div class="col-lg-7">
<div class="card shadow-sm">
    <div class="card-header">
    <h5 class="mb-4">Edit Resource</h5>
    </div>
    <div class="card-body">
    <div id="result" class="mt-3"></div>
    <?php if (isset($resource)): ?>
    <form id="resourceForm" enctype="multipart/form-data">
        <input type="hidden" name="resource_id" id="resource_id" value="<?= $resource['id']; ?>" />
        
        <div class="mb-3">
            <label>Category</label>
            <select name="category_id" class="form-select" id="category_id">
                <option value="">-- Select Category --</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= $cat['id']; ?>" <?= $cat['id'] == $resource['category_id'] ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($cat['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="text" name="new_category" class="form-control mt-2" id="new_category" placeholder="Or enter new category" />
        </div>
        <div class="mb-3">
            <label>Resource Name</label>
            <input type="text" name="resource_name" class="form-control" id="resource_name" value="<?= htmlspecialchars($resource['resource_name']); ?>" required />
        </div>
        <div class="mb-3">
            <label>Upload File</label>
            <input type="file" name="resource_file" class="form-control" id="resource_file" accept=".pdf,.doc,.docx,.mp4,.mov,.avi" />
            <p>Existing File: <a href="<?= $resource['file_path']; ?>" target="_blank">View File</a></p>
        </div>
        <button type="submit" class="btn btn-primary" id="submitBtn">Update</button>
    </form>
    <?php else: ?>
        <div class="alert alert-danger">Resource not found!</div>
    <?php endif; ?>
    </div>
</div>
    </div>
   </div>

   
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
    // Handle form submit (update resource)
    $("#resourceForm").on("submit", function(e) {
        e.preventDefault();
        let formData = new FormData(this);
        $.ajax({
            url: "ajax/update-resource.php", // Endpoint to handle the resource update
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function(res) {
                $("#result").html(
                    `<div class="alert alert-${res.includes('success') ? 'success' : 'danger'}">${res}</div>`
                );
                if (res.includes('Resource updated successfully')) {
                    setTimeout(function() {
                        window.location.href = "index.php"; // Redirect back to resource management page
                    }, 2000);
                }
            },
            error: function() {
                $("#result").html('<div class="alert alert-danger">Something went wrong!</div>');
            }
        });
    });
</script>
</body>
</html>
