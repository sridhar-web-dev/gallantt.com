<?php
require_once '../../config/config.php';  // Adjust path

if (!isset($_SESSION['user_id'])) {
    header("Location: " . ABS_URL . "dir/admin/login.php");
    exit();
}
session_start(); // Start session if not already started
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $currentPass = $_POST['current_password'] ?? '';
    $newPass = $_POST['new_password'] ?? '';
    $confirmPass = $_POST['confirm_password'] ?? '';
    if (!$email || !$currentPass || !$newPass || !$confirmPass) {
        $message = "Please fill all fields.";
    } elseif ($newPass !== $confirmPass) {
        $message = "New password and confirm password do not match.";
    } else {
        try {
            $db = Database::getDB();
            $stmt = $db->prepare("SELECT id, password FROM web_users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$user) {
                $message = "User not found.";
            } elseif (!password_verify($currentPass, $user['password'])) {
                $message = "Current password is incorrect.";
            } else {
                // Update password
                $hashedNewPass = password_hash($newPass, PASSWORD_DEFAULT);
                $updateStmt = $db->prepare("UPDATE web_users SET password = ? WHERE id = ?");
                $updateStmt->execute([$hashedNewPass, $user['id']]);
                clearVarnishCache();
                // Destroy session and redirect
                unset($_SESSION['user_id']);
                // Redirect to login with success alert
                echo "<script>
                        alert('Password updated successfully. Please log in again.');
                        window.location.href = 'login.php'; // Change to your login page path
                      </script>";
                exit;
            }
        } catch (PDOException $e) {
            $message = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="./components/navbar/header.css">
    <link rel="stylesheet" href="<?php echo ABS_URL ?>assets/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="icon" href="<?php echo ABS_URL ?>assets/home/gallantt-group-of-industries.svg" sizes="32x32">
    <link rel="icon" href="<?php echo ABS_URL ?>assets/home/gallantt-group-of-industries.svg" sizes="192x192">
    <link rel="apple-touch-icon" href="<?php echo ABS_URL ?>assets/home/gallantt-group-of-industries.svg">
    <style>
        .card {
            padding: 20px;
            border-radius: 10px;
        }
    </style>
</head>
<body>
<?php require_once ABS_PATH . 'dir/admin/components/navbar/header.php'; ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-5">
        <div class="card">
    <div class="card-header bg-light">
    <h5>Change Password</h5>
    </div>
    <div class="card-body">
    <?php if ($message): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="POST" action="">
        <div class="mb-3">
            <label for="email" class="form-label">User Name</label>
            <input type="text" id="email" name="email" required class="form-control" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" />
        </div>
        <div class="mb-3">
            <label for="current_password" class="form-label">Current Password</label>
            <input type="password" id="current_password" name="current_password" required class="form-control" />
        </div>
        <div class="mb-3">
            <label for="new_password" class="form-label">New Password</label>
            <input type="password" id="new_password" name="new_password" required class="form-control" />
        </div>
        <div class="mb-3">
            <label for="confirm_password" class="form-label">Confirm New Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required class="form-control" />
        </div>
        <button type="submit" class="btn btn-primary">Update Password</button>
    </form>
    </div>
</div>
        </div>
    </div>
</div>
</body>
<script src="<?php echo ABS_URL ?>assets/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</html>
